﻿namespace ElevatedTutors.Models
{
    public class AdminDashboardViewModel
    {
        public int TotalMembers { get; set; }
        public int TutorCount { get; set; }
        public int StudentCount { get; set; }
        public int PendingUsersCount { get; set; }
    }
}
