﻿using Microsoft.AspNetCore.Authorization;

namespace ElevatedTutors.Filters
{
    public class ApprovedUserRequirement: IAuthorizationRequirement 
    {
    }
}
